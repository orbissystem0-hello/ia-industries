package kr.aerosky.iaindustries.entity;

import immersive_aircraft.entity.AircraftEntity;
import kr.aerosky.iaindustries.IAIndustries;
import net.minecraft.world.entity.EntityType;
import net.minecraft.world.item.Item;
import net.minecraft.world.level.Level;

public class CargoGyrodyneEntity extends PoweredGyrodyneEntity {
    public CargoGyrodyneEntity(EntityType<? extends AircraftEntity> type, Level level) {
        super(type, level);
    }

    @Override
    public Item asItem() {
        return IAIndustries.CARGO_GYRODYNE_ITEM.get();
    }

    /** extra third-person camera distance in blocks */
    @Override
    public double getZoom() {
        return 5.0;
    }
}
