package kr.aerosky.iaindustries.client;

import com.mojang.blaze3d.vertex.PoseStack;
import immersive_aircraft.client.render.entity.weaponRenderer.WeaponRenderer;
import immersive_aircraft.entity.VehicleEntity;
import immersive_aircraft.entity.weapon.Weapon;
import kr.aerosky.iaindustries.entity.HawkEntity;
import net.minecraft.client.renderer.MultiBufferSource;
import net.minecraft.resources.ResourceLocation;

/** Draws the normal weapon model everywhere, and the Hawk's own model when the weapon is mounted on a Hawk. */
public class HawkWeaponRenderer extends WeaponRenderer<Weapon> {
    private final ResourceLocation normal;
    private final ResourceLocation onHawk;
    private ResourceLocation current;

    public HawkWeaponRenderer(ResourceLocation normal, ResourceLocation onHawk) {
        this.normal = normal;
        this.onHawk = onHawk;
        this.current = normal;
    }

    @Override
    public <T extends VehicleEntity> void render(T entity, Weapon weapon, PoseStack matrixStack, MultiBufferSource buffers, int light, float time) {
        this.current = entity instanceof HawkEntity ? this.onHawk : this.normal;
        super.render(entity, weapon, matrixStack, buffers, light, time);
    }

    @Override
    protected ResourceLocation getModelId() {
        return this.current;
    }
}
