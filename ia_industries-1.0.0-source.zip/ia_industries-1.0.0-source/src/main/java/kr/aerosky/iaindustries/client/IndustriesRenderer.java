package kr.aerosky.iaindustries.client;

import immersive_aircraft.client.render.entity.renderer.AircraftEntityRenderer;
import immersive_aircraft.client.render.entity.renderer.utils.ModelPartRenderHandler;
import immersive_aircraft.entity.AircraftEntity;
import kr.aerosky.iaindustries.IAIndustries;
import net.minecraft.client.renderer.entity.EntityRendererProvider;
import net.minecraft.resources.ResourceLocation;

/** One renderer for every aircraft of this mod: the model and its propeller animation live in the .bbmodel file. */
public class IndustriesRenderer<T extends AircraftEntity> extends AircraftEntityRenderer<T> {
    private final ResourceLocation modelId;
    private final ModelPartRenderHandler<T> model;

    public IndustriesRenderer(EntityRendererProvider.Context context, String name, float shadow) {
        this(context, name, shadow, new ModelPartRenderHandler<>());
    }

    public IndustriesRenderer(EntityRendererProvider.Context context, String name, float shadow, ModelPartRenderHandler<T> handler) {
        super(context);
        this.modelId = ResourceLocation.fromNamespaceAndPath(IAIndustries.ID, name);
        this.shadowRadius = shadow;
        this.model = handler;
    }

    @Override
    protected ResourceLocation getModelId() {
        return this.modelId;
    }

    @Override
    protected ModelPartRenderHandler<T> getModel(AircraftEntity entity) {
        return this.model;
    }
}
