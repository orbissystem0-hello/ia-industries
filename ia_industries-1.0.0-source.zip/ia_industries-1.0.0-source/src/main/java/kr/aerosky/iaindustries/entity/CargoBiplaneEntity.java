package kr.aerosky.iaindustries.entity;

import immersive_aircraft.entity.AircraftEntity;
import kr.aerosky.iaindustries.IAIndustries;
import net.minecraft.world.entity.EntityType;
import net.minecraft.world.item.Item;
import net.minecraft.world.level.Level;
import immersive_aircraft.entity.BiplaneEntity;

public class CargoBiplaneEntity extends BiplaneEntity {
    public CargoBiplaneEntity(EntityType<? extends AircraftEntity> type, Level level) {
        super(type, level);
    }

    @Override
    public Item asItem() {
        return IAIndustries.CARGO_BIPLANE_ITEM.get();
    }

    /** extra third-person camera distance in blocks */
    @Override
    public double getZoom() {
        return 6.0;
    }
}
