package kr.aerosky.iaindustries.client;

import com.mojang.math.Axis;
import immersive_aircraft.Main;
import immersive_aircraft.WeaponRendererRegistry;
import immersive_aircraft.client.render.entity.renderer.utils.ModelPartRenderHandler;
import kr.aerosky.iaindustries.IAIndustries;
import kr.aerosky.iaindustries.entity.PelicanEntity;
import net.minecraft.resources.ResourceLocation;
import net.minecraft.util.Mth;
import net.neoforged.bus.api.IEventBus;
import net.neoforged.fml.event.lifecycle.FMLClientSetupEvent;
import net.neoforged.neoforge.client.event.EntityRenderersEvent;

public final class ClientSetup {
    private ClientSetup() {}

    public static void init(IEventBus modBus) {
        modBus.addListener(ClientSetup::registerRenderers);
        modBus.addListener(ClientSetup::clientSetup);
    }

    private static ResourceLocation id(String path) {
        return ResourceLocation.fromNamespaceAndPath(IAIndustries.ID, path);
    }

    /** Hawk shows its own ballista / twin autocannon instead of the standard weapon models. */
    private static void clientSetup(FMLClientSetupEvent e) {
        e.enqueueWork(() -> {
            WeaponRendererRegistry.register(Main.locate("heavy_crossbow"), new HawkWeaponRenderer(Main.locate("heavy_crossbow"), id("hawk_ballista")));
            WeaponRendererRegistry.register(Main.locate("rotary_cannon"), new HawkWeaponRenderer(Main.locate("rotary_cannon"), id("hawk_autocannon")));
        });
    }

    /** tail propellers of the pelican: spin only while the tail engines run (on the water) */
    private static void spinRear(PelicanEntity entity, float yaw, float time, com.mojang.blaze3d.vertex.PoseStack pose, float dir) {
        float partial = (time * 20.0f) % 1.0f;
        pose.mulPose(Axis.ZP.rotationDegrees(Mth.lerp(partial, entity.prevRearRotation, entity.rearRotation) * 150.0f * dir));
    }

    private static void registerRenderers(EntityRenderersEvent.RegisterRenderers e) {
        e.registerEntityRenderer(IAIndustries.CARGO_COPTER.get(), c -> new IndustriesRenderer<>(c, "cargo_copter", 1.2f));
        e.registerEntityRenderer(IAIndustries.HAWK.get(), c -> new IndustriesRenderer<>(c, "hawk", 2.0f));
        e.registerEntityRenderer(IAIndustries.CARGO_GYRODYNE.get(), c -> new IndustriesRenderer<>(c, "cargo_gyrodyne", 1.3f));
        e.registerEntityRenderer(IAIndustries.DRAGONFLY.get(), c -> new IndustriesRenderer<>(c, "dragonfly", 2.6f));
        e.registerEntityRenderer(IAIndustries.CARGO_BIPLANE.get(), c -> new IndustriesRenderer<>(c, "cargo_biplane", 1.5f));
        e.registerEntityRenderer(IAIndustries.GIGANTIA.get(), c -> new IndustriesRenderer<>(c, "gigantia", 3.5f));
        e.registerEntityRenderer(IAIndustries.CARGO_SEAPLANE.get(), c -> new IndustriesRenderer<>(c, "cargo_seaplane", 1.8f));
        e.registerEntityRenderer(IAIndustries.PELICAN.get(), c -> new IndustriesRenderer<>(c, "pelican", 2.6f,
                new ModelPartRenderHandler<PelicanEntity>()
                        .add("rear_a", (entity, yaw, time, pose) -> spinRear(entity, yaw, time, pose, 1.0f))
                        .add("rear_b", (entity, yaw, time, pose) -> spinRear(entity, yaw, time, pose, -1.0f))));
    }
}
