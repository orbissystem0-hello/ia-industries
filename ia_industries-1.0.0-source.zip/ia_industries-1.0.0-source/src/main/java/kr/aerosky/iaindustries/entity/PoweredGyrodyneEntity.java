package kr.aerosky.iaindustries.entity;

import immersive_aircraft.entity.AircraftEntity;
import immersive_aircraft.entity.Rotorcraft;
import immersive_aircraft.item.upgrade.VehicleStat;
import net.minecraft.world.entity.EntityType;
import net.minecraft.world.level.Level;
import org.joml.Vector3f;

/**
 * Engine driven gyrodyne (cargo gyrodyne, dragonfly): burns boiler fuel instead of the pilot's hunger,
 * lifts off vertically, and builds up forward thrust slowly once the pilot pushes forward.
 */
public abstract class PoweredGyrodyneEntity extends Rotorcraft {
    /** share of the gap to the wanted forward thrust closed per tick (0.02 = about 3 seconds to 80%) */
    public static final float SPOOL_RATE = 0.02f;
    /** reverse thrust relative to forward thrust */
    public static final float REVERSE = 0.4f;
    private float forwardSpool;

    public PoweredGyrodyneEntity(EntityType<? extends AircraftEntity> type, Level level) {
        super(type, level, true);
    }

    @Override
    protected double getDefaultGravity() {
        return (double) (1.0f - this.getEnginePower()) * super.getDefaultGravity();
    }

    @Override
    protected void updateController() {
        super.updateController();
        if (this.canTurnOnEngine(this.getControllingPassenger())) {
            this.setEngineTarget(1.0f);
        }
        float power = this.getEnginePower();
        double up = power * this.getProperties().get(VehicleStat.VERTICAL_SPEED) * this.pressingInterpolatedY.getSmooth();
        float want = this.pressingInterpolatedZ.getSmooth();
        if (want < 0.0f) want *= REVERSE;
        this.forwardSpool += (want - this.forwardSpool) * SPOOL_RATE;
        float thrust = power * power * this.getProperties().get(VehicleStat.ENGINE_SPEED) * this.forwardSpool;
        Vector3f f = this.getForwardDirection().mul(thrust);
        this.setDeltaMovement(this.getDeltaMovement().add(f.x(), up + f.y(), f.z()));
    }
}
