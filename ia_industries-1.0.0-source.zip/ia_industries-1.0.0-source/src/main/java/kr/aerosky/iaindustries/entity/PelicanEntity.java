package kr.aerosky.iaindustries.entity;

import immersive_aircraft.entity.AircraftEntity;
import immersive_aircraft.entity.BambooHopperEntity;
import kr.aerosky.iaindustries.IAIndustries;
import net.minecraft.core.BlockPos;
import net.minecraft.util.Mth;
import net.minecraft.world.entity.EntityType;
import net.minecraft.world.item.Item;
import net.minecraft.world.level.Level;
import net.minecraft.world.phys.Vec3;
import org.joml.Vector3f;

/**
 * Sea skimmer (a wing-in-ground craft that can also fly): fast on the water where all four engines run,
 * slower and clumsier in the air. It stays on the water until the pilot deliberately pulls up.
 */
public class PelicanEntity extends BambooHopperEntity {
    /** forward push per tick from the two tail engines at full power (water only) */
    public static final double WATER_THRUST = 0.035;
    /** speed (blocks per second) at which the tail engines stop adding thrust */
    public static final double WATER_MAX_SPEED = 19.0;
    /** extra top speed (blocks per second) at full rain + thunder */
    public static final double STORM_SPEED = 1.5;
    /** fuel use in the air relative to the water (tail engines off) */
    public static final float AIR_FUEL = 0.6f;
    /** how far back the pitch control must be held before the hull is allowed to leave the water */
    public static final float PULL_UP = -0.35f;
    /** turn and pitch rate in the air relative to the water */
    public static final float AIR_YAW = 0.55f;
    public static final float AIR_PITCH = 0.75f;
    /** water within this many blocks below still counts as skimming */
    public static final int SKIM_HEIGHT = 2;

    /** 0..1, how far the tail engines have spun up */
    public float rearPower;
    public float rearRotation;
    public float prevRearRotation;
    private boolean overWater;

    public PelicanEntity(EntityType<? extends AircraftEntity> type, Level level) {
        super(type, level);
    }

    @Override
    public Item asItem() {
        return IAIndustries.PELICAN_ITEM.get();
    }

    @Override
    public double getZoom() {
        return 10.0;
    }

    private boolean checkOverWater() {
        if (this.wasTouchingWater) return true;
        BlockPos pos = this.blockPosition();
        for (int i = 0; i <= SKIM_HEIGHT; i++) {
            if (!this.level().getFluidState(pos.below(i)).isEmpty()) return true;
        }
        return false;
    }

    public boolean isPullingUp() {
        return this.pressingInterpolatedZ.getSmooth() < PULL_UP;
    }

    /** on or just above the water with the pilot not pulling up: wings give no lift, the hull stays down */
    public boolean isSkimming() {
        return this.overWater && !this.isPullingUp();
    }

    @Override
    protected double getDefaultGravity() {
        double gravity = super.getDefaultGravity();
        if (gravity >= 0.0 && this.isSkimming()) return 0.04;
        return gravity;
    }

    @Override
    protected void updateController() {
        float yaw = this.getYRot();
        float pitch = this.getXRot();
        super.updateController();
        if (!this.overWater && !this.onGround()) {
            this.setYRot(yaw + (this.getYRot() - yaw) * AIR_YAW);
            this.setXRot(pitch + (this.getXRot() - pitch) * AIR_PITCH);
        }
    }

    @Override
    public float getFuelConsumption() {
        return super.getFuelConsumption() * (AIR_FUEL + (1.0f - AIR_FUEL) * this.rearPower);
    }

    @Override
    public void tick() {
        this.overWater = this.checkOverWater();
        super.tick();
        float power = this.getEnginePower();
        float target = this.wasTouchingWater && power > 0.05f ? power : 0.0f;
        this.rearPower += (target - this.rearPower) * 0.08f;
        if (this.level().isClientSide) {
            if (this.rearRotation > 1000.0f) this.rearRotation -= 1000.0f;
            this.prevRearRotation = this.rearRotation;
            this.rearRotation += this.rearPower;
        }
        if (this.getControllingPassenger() == null || !this.isControlledByLocalInstance()) return;
        Vec3 v = this.getDeltaMovement();
        if (this.isSkimming() && v.y > 0.0) {
            v = new Vec3(v.x, v.y * 0.5, v.z);
        }
        if (this.rearPower >= 0.01f && this.wasTouchingWater) {
            Vector3f d = this.getForwardDirection();
            double speed = Math.max(0.0, v.x * d.x() + v.z * d.z()) * 20.0;
            double storm = this.level().getRainLevel(1.0f) + this.level().getThunderLevel(1.0f);
            double max = WATER_MAX_SPEED + storm * STORM_SPEED;
            double k = WATER_THRUST * this.rearPower * this.rearPower * Mth.clamp((1.0 - speed / max) / 0.25, 0.0, 1.0);
            v = v.add(d.x() * k, 0.0, d.z() * k);
        }
        this.setDeltaMovement(v);
    }
}
