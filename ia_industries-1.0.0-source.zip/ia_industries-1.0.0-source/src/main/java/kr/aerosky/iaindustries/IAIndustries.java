package kr.aerosky.iaindustries;

import immersive_aircraft.Entities;
import immersive_aircraft.config.Config;
import immersive_aircraft.entity.bullet.BulletEntity;
import immersive_aircraft.item.AircraftItem;
import kr.aerosky.iaindustries.entity.*;
import net.minecraft.core.registries.Registries;
import net.minecraft.network.chat.Component;
import net.minecraft.world.entity.Entity;
import net.minecraft.world.entity.EntityType;
import net.minecraft.world.entity.MobCategory;
import net.minecraft.world.entity.projectile.AbstractArrow;
import net.minecraft.world.item.CreativeModeTab;
import net.minecraft.world.item.Item;
import net.minecraft.world.item.ItemStack;
import net.minecraft.world.phys.Vec3;
import net.neoforged.api.distmarker.Dist;
import net.neoforged.bus.api.IEventBus;
import net.neoforged.fml.common.Mod;
import net.neoforged.fml.loading.FMLEnvironment;
import net.neoforged.neoforge.common.NeoForge;
import net.neoforged.neoforge.event.entity.EntityJoinLevelEvent;
import net.neoforged.neoforge.registries.DeferredHolder;
import net.neoforged.neoforge.registries.DeferredRegister;

@Mod(IAIndustries.ID)
public class IAIndustries {
    public static final String ID = "ia_industries";

    /** Hawk: heavy crossbow bolts deal this many times their damage. */
    public static final double HAWK_CROSSBOW_DAMAGE = 2.0;
    /** Hawk: rotary cannon bullets deal this many times their damage. */
    public static final float HAWK_CANNON_DAMAGE = 1.5f;
    /** Hawk: every Nth cannon shot fires a second barrel (2 = +50% rate of fire). */
    public static final int HAWK_EXTRA_SHOT_EVERY = 2;

    public static final DeferredRegister<EntityType<?>> ENTITIES = DeferredRegister.create(Registries.ENTITY_TYPE, ID);
    public static final DeferredRegister<Item> ITEMS = DeferredRegister.create(Registries.ITEM, ID);
    public static final DeferredRegister<CreativeModeTab> TABS = DeferredRegister.create(Registries.CREATIVE_MODE_TAB, ID);

    public static final DeferredHolder<EntityType<?>, EntityType<CargoCopterEntity>> CARGO_COPTER = ENTITIES.register("cargo_copter", () -> EntityType.Builder.<CargoCopterEntity>of(CargoCopterEntity::new, MobCategory.MISC).sized(2.0f, 1.8f).clientTrackingRange(12).build(ID + ":cargo_copter"));
    public static final DeferredHolder<EntityType<?>, EntityType<HawkEntity>> HAWK = ENTITIES.register("hawk", () -> EntityType.Builder.<HawkEntity>of(HawkEntity::new, MobCategory.MISC).sized(3.2f, 2.8f).clientTrackingRange(14).build(ID + ":hawk"));
    public static final DeferredHolder<EntityType<?>, EntityType<CargoGyrodyneEntity>> CARGO_GYRODYNE = ENTITIES.register("cargo_gyrodyne", () -> EntityType.Builder.<CargoGyrodyneEntity>of(CargoGyrodyneEntity::new, MobCategory.MISC).sized(2.0f, 2.0f).clientTrackingRange(12).build(ID + ":cargo_gyrodyne"));
    public static final DeferredHolder<EntityType<?>, EntityType<DragonflyEntity>> DRAGONFLY = ENTITIES.register("dragonfly", () -> EntityType.Builder.<DragonflyEntity>of(DragonflyEntity::new, MobCategory.MISC).sized(3.6f, 3.8f).clientTrackingRange(16).build(ID + ":dragonfly"));
    public static final DeferredHolder<EntityType<?>, EntityType<CargoBiplaneEntity>> CARGO_BIPLANE = ENTITIES.register("cargo_biplane", () -> EntityType.Builder.<CargoBiplaneEntity>of(CargoBiplaneEntity::new, MobCategory.MISC).sized(2.6f, 1.9f).clientTrackingRange(12).build(ID + ":cargo_biplane"));
    public static final DeferredHolder<EntityType<?>, EntityType<GigantiaEntity>> GIGANTIA = ENTITIES.register("gigantia", () -> EntityType.Builder.<GigantiaEntity>of(GigantiaEntity::new, MobCategory.MISC).sized(5.0f, 3.0f).clientTrackingRange(18).build(ID + ":gigantia"));
    public static final DeferredHolder<EntityType<?>, EntityType<CargoSeaplaneEntity>> CARGO_SEAPLANE = ENTITIES.register("cargo_seaplane", () -> EntityType.Builder.<CargoSeaplaneEntity>of(CargoSeaplaneEntity::new, MobCategory.MISC).sized(3.2f, 1.8f).clientTrackingRange(14).build(ID + ":cargo_seaplane"));
    public static final DeferredHolder<EntityType<?>, EntityType<PelicanEntity>> PELICAN = ENTITIES.register("pelican", () -> EntityType.Builder.<PelicanEntity>of(PelicanEntity::new, MobCategory.MISC).sized(4.0f, 2.5f).clientTrackingRange(16).build(ID + ":pelican"));

    public static final DeferredHolder<Item, Item> CARGO_COPTER_ITEM = ITEMS.register("cargo_copter", () -> new AircraftItem(new Item.Properties().stacksTo(1), level -> new CargoCopterEntity(CARGO_COPTER.get(), level)));
    public static final DeferredHolder<Item, Item> HAWK_ITEM = ITEMS.register("hawk", () -> new AircraftItem(new Item.Properties().stacksTo(1), level -> new HawkEntity(HAWK.get(), level)));
    public static final DeferredHolder<Item, Item> CARGO_GYRODYNE_ITEM = ITEMS.register("cargo_gyrodyne", () -> new AircraftItem(new Item.Properties().stacksTo(1), level -> new CargoGyrodyneEntity(CARGO_GYRODYNE.get(), level)));
    public static final DeferredHolder<Item, Item> DRAGONFLY_ITEM = ITEMS.register("dragonfly", () -> new AircraftItem(new Item.Properties().stacksTo(1), level -> new DragonflyEntity(DRAGONFLY.get(), level)));
    public static final DeferredHolder<Item, Item> CARGO_BIPLANE_ITEM = ITEMS.register("cargo_biplane", () -> new AircraftItem(new Item.Properties().stacksTo(1), level -> new CargoBiplaneEntity(CARGO_BIPLANE.get(), level)));
    public static final DeferredHolder<Item, Item> GIGANTIA_ITEM = ITEMS.register("gigantia", () -> new AircraftItem(new Item.Properties().stacksTo(1), level -> new GigantiaEntity(GIGANTIA.get(), level)));
    public static final DeferredHolder<Item, Item> CARGO_SEAPLANE_ITEM = ITEMS.register("cargo_seaplane", () -> new AircraftItem(new Item.Properties().stacksTo(1), level -> new CargoSeaplaneEntity(CARGO_SEAPLANE.get(), level)));
    public static final DeferredHolder<Item, Item> PELICAN_ITEM = ITEMS.register("pelican", () -> new AircraftItem(new Item.Properties().stacksTo(1), level -> new PelicanEntity(PELICAN.get(), level)));

    public static final DeferredHolder<CreativeModeTab, CreativeModeTab> TAB = TABS.register("aircraft", () -> CreativeModeTab.builder(CreativeModeTab.Row.TOP, 0)
            .title(Component.translatable("itemGroup." + ID + ".aircraft"))
            .icon(() -> new ItemStack(HAWK_ITEM.get()))
            .displayItems((params, out) -> {
                out.accept(CARGO_COPTER_ITEM.get());
                out.accept(HAWK_ITEM.get());
                out.accept(CARGO_GYRODYNE_ITEM.get());
                out.accept(DRAGONFLY_ITEM.get());
                out.accept(CARGO_BIPLANE_ITEM.get());
                out.accept(GIGANTIA_ITEM.get());
                out.accept(CARGO_SEAPLANE_ITEM.get());
                out.accept(PELICAN_ITEM.get());
            }).build());

    private static final ThreadLocal<Boolean> SPAWNING_EXTRA = ThreadLocal.withInitial(() -> false);
    private static final java.util.Map<HawkEntity, Integer> SHOTS = new java.util.WeakHashMap<>();

    public IAIndustries(IEventBus modBus) {
        ENTITIES.register(modBus);
        ITEMS.register(modBus);
        TABS.register(modBus);
        NeoForge.EVENT_BUS.addListener(IAIndustries::onEntityJoin);
        if (FMLEnvironment.dist == Dist.CLIENT) {
            kr.aerosky.iaindustries.client.ClientSetup.init(modBus);
        }
    }

    private static HawkEntity hawkOf(Entity owner) {
        if (owner == null) return null;
        return owner.getRootVehicle() instanceof HawkEntity hawk ? hawk : null;
    }

    /** Hawk weapon bonuses, applied to the projectiles its weapons spawn (server side only). */
    private static void onEntityJoin(EntityJoinLevelEvent event) {
        if (event.getLevel().isClientSide() || event.loadedFromDisk()) return;
        Entity entity = event.getEntity();
        if (entity instanceof AbstractArrow arrow) {
            if (arrow.pickup == AbstractArrow.Pickup.DISALLOWED && hawkOf(arrow.getOwner()) != null) {
                arrow.setBaseDamage(arrow.getBaseDamage() * HAWK_CROSSBOW_DAMAGE);
            }
        } else if (entity instanceof BulletEntity bullet) {
            HawkEntity hawk = hawkOf(bullet.getOwner());
            if (hawk == null) return;
            if (SPAWNING_EXTRA.get()) return;
            bullet.setDamage(Config.getInstance().rotaryCannonDamage * HAWK_CANNON_DAMAGE);
            int shots = SHOTS.merge(hawk, 1, Integer::sum);
            if (HAWK_EXTRA_SHOT_EVERY > 0 && shots % HAWK_EXTRA_SHOT_EVERY == 0) {
                BulletEntity extra = Entities.BULLET.get().create(bullet.level());
                if (extra == null) return;
                Vec3 v = bullet.getDeltaMovement();
                Vec3 side = new Vec3(-v.z, 0.0, v.x);
                if (side.lengthSqr() > 1.0e-6) side = side.normalize().scale(0.45);
                extra.setDamage(Config.getInstance().rotaryCannonDamage * HAWK_CANNON_DAMAGE);
                extra.setPos(bullet.getX() + side.x, bullet.getY(), bullet.getZ() + side.z);
                extra.setOwner(bullet.getOwner());
                extra.setDeltaMovement(v);
                SPAWNING_EXTRA.set(true);
                try {
                    bullet.level().addFreshEntity(extra);
                } finally {
                    SPAWNING_EXTRA.set(false);
                }
            }
        }
    }
}
