package kr.aerosky.iaindustries.entity;

import immersive_aircraft.entity.AircraftEntity;
import kr.aerosky.iaindustries.IAIndustries;
import net.minecraft.world.entity.EntityType;
import net.minecraft.world.item.Item;
import net.minecraft.world.level.Level;

public class DragonflyEntity extends PoweredGyrodyneEntity {
    public DragonflyEntity(EntityType<? extends AircraftEntity> type, Level level) {
        super(type, level);
    }

    @Override
    public Item asItem() {
        return IAIndustries.DRAGONFLY_ITEM.get();
    }

    /** extra third-person camera distance in blocks */
    @Override
    public double getZoom() {
        return 9.0;
    }
}
